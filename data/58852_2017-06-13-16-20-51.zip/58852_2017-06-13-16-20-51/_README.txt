Weater data requested on 6/13/2017 4:20 PM.

South Latitude: 10.6862
West Longitude: 106.5159
North Latitude: 10.8684
East Longitude: 106.7617
Number of Weather Stations: 1

Start Date: 1/1/1979
End Date: 7/31/2014

Data Collected:
Temperature (C): Yes
Precipitation (mm): Yes
Wind (m/s): Yes
Relative Humidity (fraction): Yes
Solar (MJ/m^2): Yes

Generate SWAT Files? No
Generate CSV File? Yes
